<template>
  <v-avatar max-width="100px">
    <img src="~static/logo.svg" alt="" />
  </v-avatar>
</template>

<script>
export default {
  name: "Logo"
}
</script>

<style scoped>

</style>
