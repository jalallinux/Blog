<?php

return [
    'forbidden' => 'شما دسترسی برای انجام این عملیات ندارید.',
    'delete' => [
        'success' => ':attribute با موفقیت حذف شد.',
        'failed' => ':attribute حذف نشد.',
    ]
];
